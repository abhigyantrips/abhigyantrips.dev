from django import forms

class FirstPageForm(forms.Form):
    name = forms.CharField(label="Name", max_length=100)
    roll = forms.CharField(label="Roll Number", max_length=20)
    subjects = forms.ChoiceField(
        choices=[
            ("Math", "Math"),
            ("Science", "Science"),
            ("English", "English"),
        ],
        label="Subject",
    )
