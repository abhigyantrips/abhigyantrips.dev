from django.urls import path
from . import views

urlpatterns = [
    path("first/", views.first_page_view, name="first_page"),
    path("second/", views.second_page_view, name="second_page"),
]
