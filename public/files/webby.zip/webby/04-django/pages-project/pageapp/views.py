from django.shortcuts import render, redirect
from .forms import FirstPageForm

def first_page_view(request):
    if request.method == "POST":
        form = FirstPageForm(request.POST)
        if form.is_valid():
            request.session["name"] = form.cleaned_data["name"]
            request.session["roll"] = form.cleaned_data["roll"]
            request.session["subjects"] = form.cleaned_data["subjects"]
            return redirect("second_page")
    else:
        form = FirstPageForm()
    return render(request, "firstPage.html", {"form": form})


def second_page_view(request):
    name = request.session.get("name", "No name found")
    roll = request.session.get("roll", "No roll found")
    subjects = request.session.get("subjects", "No subject found")
    context = {"name": name, "roll": roll, "subjects": subjects}
    return render(request, "secondPage.html", context)
