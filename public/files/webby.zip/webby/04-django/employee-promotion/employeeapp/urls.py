from django.urls import path
from . import views

urlpatterns = [
    path("promotion/", views.promotion_check_view, name="promotion_check"),
]
