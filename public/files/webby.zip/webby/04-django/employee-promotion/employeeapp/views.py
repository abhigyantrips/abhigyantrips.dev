from django.shortcuts import render
from .forms import PromotionCheckForm
from datetime import date

def promotion_check_view(request):
    result = ""
    if request.method == "POST":
        form = PromotionCheckForm(request.POST)
        if form.is_valid():
            joining_date = form.cleaned_data["date_of_joining"]
            today = date.today()
            experience_years = today.year - joining_date.year - ((today.month, today.day) < (joining_date.month, joining_date.day))

            if experience_years >= 5:
                result = "YES"
            else:
                result = "NO"
    else:
        form = PromotionCheckForm()
    return render(
        request, "promotion_check.html", {"form": form, "result": result}
    )
