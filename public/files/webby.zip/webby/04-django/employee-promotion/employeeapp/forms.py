from django import forms
from datetime import date


class PromotionCheckForm(forms.Form):
    employee_id = forms.ChoiceField(
        choices=[(1, "Emp1"), (2, "Emp2"), (3, "Emp3")], label="Employee ID"
    )
    date_of_joining = forms.DateField(label="Date of Joining")
