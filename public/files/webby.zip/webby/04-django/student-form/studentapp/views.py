from django.shortcuts import render

from .forms import StudentDetailsForm

def student_form_view(request):
    details = ""
    percentage = ""
    if request.method == "POST":
        form = StudentDetailsForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data["name"]
            dob = form.cleaned_data["dob"]
            address = form.cleaned_data["address"]
            contact_number = form.cleaned_data["contact_number"]
            email = form.cleaned_data["email"]
            english_marks = form.cleaned_data["english_marks"]
            physics_marks = form.cleaned_data["physics_marks"]
            chemistry_marks = form.cleaned_data["chemistry_marks"]
            total_marks = english_marks + physics_marks + chemistry_marks
            percentage = (total_marks / 300) * 100
            details = f"Name: {name}\nDOB: {dob}\nAddress: {address}\nContact: {contact_number}\nEmail: {email}\nEnglish: {english_marks}\nPhysics: {physics_marks}\nChemistry: {chemistry_marks}"
    else:
        form = StudentDetailsForm()
    return render(
        request,
        "student_form.html",
        {"form": form, "details": details, "percentage": percentage},
    )
