from django import forms

class StudentDetailsForm(forms.Form):
    name = forms.CharField(max_length=100, label="Name")
    dob = forms.DateField(label="Date of Birth")
    address = forms.CharField(widget=forms.Textarea, label="Address")
    contact_number = forms.CharField(max_length=20, label="Contact Number")
    email = forms.EmailField(label="Email ID")
    english_marks = forms.IntegerField(label="English Marks")
    physics_marks = forms.IntegerField(label="Physics Marks")
    chemistry_marks = forms.IntegerField(label="Chemistry Marks")
