from django.urls import path

from . import views

urlpatterns = [path("student/", views.student_form_view, name="student_form")]
