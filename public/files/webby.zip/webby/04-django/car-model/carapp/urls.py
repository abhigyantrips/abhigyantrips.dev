from django.urls import path
from . import views

urlpatterns = [
    path("car/", views.car_form_view, name="car_form"),
    path(
        "car_details/<str:manufacturer>/<str:model>/",
        views.car_details_view,
        name="car_details",
    ),
]
