from django import forms

class CarForm(forms.Form):
    manufacturer = forms.ChoiceField(
        choices=[
            ("Toyota", "Toyota"),
            ("Honda", "Honda"),
            ("Ford", "Ford"),
            ("BMW", "BMW"),
        ],
        label="Car Manufacturer",
    )
    model = forms.CharField(max_length=100, label="Model Name")
