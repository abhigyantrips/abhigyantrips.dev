from django.shortcuts import render, redirect
from .forms import CarForm

def car_form_view(request):
    if request.method == "POST":
        form = CarForm(request.POST)
        if form.is_valid():
            manufacturer = form.cleaned_data["manufacturer"]
            model = form.cleaned_data["model"]
            return redirect(
                "car_details", manufacturer=manufacturer, model=model
            )
    else:
        form = CarForm()
    return render(request, "car_form.html", {"form": form})


def car_details_view(request, manufacturer, model):
    return render(
        request,
        "car_details.html",
        {"manufacturer": manufacturer, "model": model},
    )
